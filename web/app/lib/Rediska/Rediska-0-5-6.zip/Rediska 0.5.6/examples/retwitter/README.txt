ReTwitter
Twitter clone based on Zend Framework and Rediska.