<?php

class Rediska_Connection_ExecTest extends Rediska_TestCase
{
    public function testWrite()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testRead()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testExecute()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testTransformMultiBulkCommand()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testReadResponseFromConnection()
    {
        $this->markTestIncomplete('Write me!');
    }
}