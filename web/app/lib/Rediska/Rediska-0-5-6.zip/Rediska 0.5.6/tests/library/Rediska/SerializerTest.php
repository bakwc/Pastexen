<?php

class Rediska_SerializerTest extends Rediska_TestCase
{
    public function testSetAdapter()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testGetAdapter()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testSerialize()
    {
        $this->markTestIncomplete('Write me!');
    }

    public function testUnserialize()
    {
        $this->markTestIncomplete('Write me!');
    }
}