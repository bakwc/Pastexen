<?php

class Rediska_Command_RewriteAppendOnlyFileTest extends Rediska_TestCase
{
    public function testRewriteAppendOnlyFile()
    {
        $this->markTestIncomplete('Not tested!');
    }
}