<?php

class Rediska_ConnectionTest extends Rediska_TestCase
{
    public function testConnect()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testDisconnect()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testIsConnected()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testWrite()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testRead()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testReadLine()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testGetTimeout()
    {
        $this->markTestIncomplete('Write me!');
    }
    
    public function testGetAlias()
    {
        $this->markTestIncomplete('Write me!');
    }
}