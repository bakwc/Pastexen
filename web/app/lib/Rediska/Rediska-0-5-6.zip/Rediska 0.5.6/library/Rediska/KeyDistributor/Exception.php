<?php

/**
 * Rediska key distributor exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage Key distributor
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_KeyDistributor_Exception extends Rediska_Exception
{
    
}