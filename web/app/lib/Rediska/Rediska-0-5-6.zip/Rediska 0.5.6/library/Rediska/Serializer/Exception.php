<?php

/**
 * Rediska serializer exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage Serializer
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Serializer_Exception extends Rediska_Exception
{
    
}