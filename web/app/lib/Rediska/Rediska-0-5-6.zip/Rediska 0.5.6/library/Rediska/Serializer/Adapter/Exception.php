<?php

/**
 * Rediska serializer adapter exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage Serializer
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Serializer_Adapter_Exception extends Rediska_Serializer_Exception
{
    
}