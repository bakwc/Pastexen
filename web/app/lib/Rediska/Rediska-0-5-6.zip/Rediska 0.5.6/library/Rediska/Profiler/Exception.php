<?php

/**
 * Rediska profiler exception
 *
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage Profiler
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Profiler_Exception extends Rediska_Exception
{

}