<?php

/**
 * Rediska Transaction exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Transaction_AbortedException extends Rediska_Transaction_Exception
{
    
}