<?php

/**
 * Rediska key exception
 * 
 * @author Ivan Shumkov
 * @package Rediska
 * @subpackage Key objects
 * @version 0.5.6
 * @link http://rediska.geometria-lab.net
 * @license http://www.opensource.org/licenses/bsd-license.php
 */
class Rediska_Key_Exception extends Rediska_Exception
{
    
}